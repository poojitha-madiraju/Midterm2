const data = {
users : [
    {id : 1, name :'pargol'},
    {id : 2, name :'daniel'},
    {id : 3, name :'richard'}
],
}

module.exports = data;