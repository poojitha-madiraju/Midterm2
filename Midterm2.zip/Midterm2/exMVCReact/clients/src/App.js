import React from "react";
import Admin from "./components/Admin";
import Client from "./components/Client";


const App = () =>{
  return(
     <div>
        <h>this is my app</h>
        <Admin />
        <Client />
    </div>
  );
};

export default App;
