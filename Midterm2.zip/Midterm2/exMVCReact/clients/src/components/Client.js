import React, { useEffect, useState } from 'react';

const Client = () => {
  const [clientData, setClientData] = useState([]);

  useEffect(() => {
    // Fetch admin data from the server
    fetch('/client')
      .then((res) => res.json())
      .then((data) => setClientData(data));
  }, []);

  return (
    <div>
      <h2>Client Page</h2>
      <p>djkgfjgdfgdfgsfgd</p>
      <ul>
        {clientData.map((item, index) => (
          <li key={index}>{item}</li>
        ))}
      </ul>
    </div>
  );
};

export default Client;