import React, { useEffect, useState } from 'react';
import AddAdminData from './AddAdminData';

const Admin = () => {
  const [adminData, setAdminData] = useState([]);

  useEffect(() => {
    // Fetch admin data from the server
    fetch('/admin')
      .then((res) => res.json())
      .then((data) => setAdminData(data));
  }, []);


  // const addData =(newdata) =>{
  //   fetch('/admin/add', {
  //     method: 'POST',
  //     headers: {
  //       'Content-Type': 'application/json',
  //     },
  //     body: JSON.stringify(newData),
  //   })
  //     .then((res) => res.json())
  //     .then((data) => {
  //       console.log(data.message);
  //     fetch('/admin')
  //     .then((res) => res.json())
  //     .then((data) => setAdminData(data));
  //   });
  // };

  const addData = async (newData) => {
    try{
      const response = await fetch('/admin/add', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ newData }),
      });
  
      const data = await response.json();
      console.log(data.message);
      const updatedAdminData = await fetch('/admin').then((res) => res.json());
      setAdminData(updatedAdminData);
    }catch(error){
      console.log("e".error)
    }

  };



  return (
    <div>
      <h2>Admin Page</h2>
      <AddAdminData onAddData={addData} />
      <ul>
        {adminData.map((item, index) => (
          <li key={index}>{item}</li>
        ))}
      </ul>
    </div>
  );
};

export default Admin;