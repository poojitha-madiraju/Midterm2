import React ,{ useEffect, useState } from 'react';

const AddAdminData = ({ onAddData}) => {
    const [newData,setNewData] = useState('');

    const handelInput = (e) =>{
        setNewData(e.target.value);
    };


    const addData = ()=>{
        setNewData(newData);
        onAddData(newData);
       // setNewData(newData);
        console.log(newData);
        setNewData('');
    }

    return(
        <div>
            <input type='text' value={newData} onChange={handelInput}></input>
            <button onClick={addData}>ADD the new data</button>
        </div>
    )
};


export default AddAdminData;